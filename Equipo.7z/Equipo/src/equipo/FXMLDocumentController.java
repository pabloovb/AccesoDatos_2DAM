
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML2.java to edit this template
 */

package equipo;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import org.xml.sax.SAXException;
/**
 * 
 *
 * @author DAM2
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;
    
    
    @FXML
    private Button botonPrevio;
    @FXML
    private Button botonSiguiente;
    @FXML
    private TextField areaNombre;
    @FXML
    private TextField areaEquipo;
    @FXML
    private TextField areaAnyo;
    @FXML
    private TextField areaPosición;
    @FXML
    private TextField areaID;
    
     Integer position;
     
     
     
     
     
     
     
     
     
     
     
     Equipo datos = new Equipo();
    
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
        
    }
    
    @Override
public void initialize(URL url, ResourceBundle rb) {
        // TODO
        position = 0;
        
        
        
        
        
        try {
            datos.LeerXML("futbolistas.xml");
            
            FutbolistaPOJO futbolista = new FutbolistaPOJO();
            futbolista=datos.Read(0);
            areaID.setText(String.valueOf(futbolista.getID()));
            areaNombre.setText(futbolista.getNombre());
            areaEquipo.setText(futbolista.getEquipo());
            areaPosición.setText(futbolista.getPosicion());
            areaAnyo.setText(String.valueOf(futbolista.getAnyo()));
            
        } catch (SAXException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
       
        
    }   
    
    }    
    

