/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML.java to edit this template
 */
package equipo;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


/**
 *
 * @author DAM2
 */
public class Equipo {
    
    List<FutbolistaPOJO> listaFutbolistas = new ArrayList<>();
    
      public void LeerXML(String path) throws SAXException, ParserConfigurationException, IOException{
        
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dbBuilder = dbFactory.newDocumentBuilder();
        Document document = dbBuilder.parse(new File(path));
        
        Element raiz = document.getDocumentElement();
        System.out.println("Contenido XML " + raiz.getNodeName() + ":");
        NodeList nodeList = document.getElementsByTagName("futbolistas");
        
        for (int i=0;i<nodeList.getLength();i++){
            Node node = nodeList.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE){
                Element eElement = (Element) node;
                FutbolistaPOJO futbolista = new FutbolistaPOJO();
                futbolista.setID(Integer.parseInt(eElement.getAttribute("id")));
                futbolista.setNombre(eElement.getElementsByTagName("Nombre").item(0).getTextContent());
                futbolista.setEquipo(eElement.getElementsByTagName("Equipo").item(0).getTextContent());
                futbolista.setAnyo(Double.parseDouble(eElement.getElementsByTagName("Año").item(0).getTextContent()));
                futbolista.setPosicion(eElement.getElementsByTagName("Posicion").item(0).getTextContent());
                
                listaFutbolistas.add(futbolista);
                
                
                
            }
        }
        
        
    }
    
    
   public FutbolistaPOJO Read(int index){
        return listaFutbolistas.get(index);
    }
    
}
