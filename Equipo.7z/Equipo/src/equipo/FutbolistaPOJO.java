/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package equipo;


/**
 *
 * @author DAM2
 */
public class FutbolistaPOJO {

 

    int ID;
    String Nombre;
    String Equipo;
    double anyo; 
    String Posicion;
    
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
        
    }

   

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

       public String getEquipo() {
        return Equipo;
    }

    public void setEquipo(String Equipo) {
        this.Equipo = Equipo;
    }

    public double getAnyo() {
        return anyo;
    }

    public void setAnyo(double anyo) {
        this.anyo = anyo;
    }

    
    public String getPosicion() {
        return Posicion;
    }

    public void setPosicion(String Posición) {
        this.Posicion = Posición;
    }
  
    

       
}
